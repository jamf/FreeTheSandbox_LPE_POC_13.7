export PATH="/private/var/containers/Bundle/jb_resources/bin:/private/var/containers/Bundle/jb_resources/sbin:/private/var/containers/Bundle/jb_resources/usr/bin:/private/var/containers/Bundle/jb_resources/usr/sbin"
bash
